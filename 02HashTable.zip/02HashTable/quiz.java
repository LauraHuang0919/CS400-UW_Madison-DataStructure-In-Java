public class quiz{

public class JavaObject {
  private int value;
  public JavaObject(int value) {
    this.value=Math.abs(value);
  }
  public int hashCode() {
    return value%10+value%100/10;
  }
 
}
public void main() {
  new JavaObject(68); 
}
}




