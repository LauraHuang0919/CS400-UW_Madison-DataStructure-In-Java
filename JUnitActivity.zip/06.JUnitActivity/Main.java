public class Main {

    public static void main(String[] args) {
	System.out.println("Start:");
  	MyList list  = new MyList();
        list.add("Ruoran");
       	list.add("Huang");
       	System.out.println("The name is: "+ list.get(0)+" "+ list.get(1));
    }
}
